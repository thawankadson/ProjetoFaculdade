from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from datetime import date , datetime, timedelta
from calendar import monthrange
import time
import datetime


config = {
    'EMAIL': 'rene',
    'PASSWORD': 'Senha@23'
}
data_atual = date.today() - timedelta(days=7)
data_i = data_atual.strftime('%d/%m/%Y')
data_f = data_atual.replace(day=monthrange(data_atual.year, data_atual.month)[1]).strftime('%d/%m/%Y')

login_url = 'https://syscor.before.com.br/_sys/?logUfIdSession=11'
relatorio_url = 'https://syscor.before.com.br/_sys/relServicosVisaoExcel.php?fi_id=685,214,822,217,213,628,774,636,216,806,215,219,218,212&indicador=3&grupoSegmento=1,2,3,4,5,6&metaServico=23,22,43,20,38,3,48,42,49,17,51,30,32,40&num_protocolo_ativo=1&modo=1&data_inicio='+data_i+'&data_fim='+data_f+'&contadigital=0&campos_analitico=vendedor,cli_nome,ve_data_ins,vsv_data,ve_hora,nota_num,nota_num_serie,dependente,tipoTroca,fidelizado,celular,num_port,nome_operadora,serial_celular,serial,promocao,recarga,recargaValor,recargaDesconto,num_protocolo,dia_venc,conta_digital,valorReceita,remuneracao_zerada,vsv_data_instalacao_servico,num_protocolo_status,vsv_servico_instalado,num_protocolo_ged,num_protocolo_data,vsv_zerar_rem_motivo,fixa_disponivel,oferta_fixa,vsv_linha_dependente,uf_sigla&excel=1&vivo_plano_tipo=2,3,1&considerarData=0&rel=1'
def main():
    driver = webdriver.Chrome('./chromedriver')
    driver.get(login_url)
    elem = driver.find_element("name", "us_email")
    elem.clear()
    elem.send_keys(config['EMAIL'])
    elem = driver.find_element("name", "us_senha")
    elem.clear()
    elem.send_keys(config['PASSWORD'])
    time.sleep(5)
    elem.send_keys(Keys.TAB)
    time.sleep(1)
    elem.send_keys(Keys.ENTER)

    time.sleep(10)

    data = {}

 

    print(data)
    time.sleep(30)
    driver.get(relatorio_url)
    time.sleep(5)
    driver.close()

if __name__ == '__main__':
    main()